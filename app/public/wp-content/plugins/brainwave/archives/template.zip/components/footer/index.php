<?php $option = get_field('page_content', 'information'); ?>
<footer>
  <div>
  </div>
</footer>
